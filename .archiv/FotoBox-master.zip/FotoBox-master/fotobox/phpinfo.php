﻿<?php
phpinfo();
?>