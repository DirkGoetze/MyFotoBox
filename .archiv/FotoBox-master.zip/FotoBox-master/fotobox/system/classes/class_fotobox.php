<?php
/* 
Filename: class_baseclass.php
Content.: class definition for the main class of fotobox application
Create..: 2020-09-24
Change..: 2020-09-24 create by D.Goetze
*/

class FotoBox extends BaseClass {
    // -- declare class propertys ----------------------------------------
    protected $Caption;                          // Caption for Headline
    protected $WelcomeMessage;                   // frist message 
    // -- declate protected class constantes -----------------------------
    // -- declate private class constantes -------------------------------
    // -- get/set propertys ----------------------------------------------
    function getCaption () {
        // function: getCaption()
        // parameter: none
        $this->debug_log(__FUNCTION__);
        return $this->Caption;
    }
    function setCaption( $Value ) {
        // function: setCaption()
        // parameter: Value = new value for this property
        $this->debug_log(__FUNCTION__, $Value);
        $this->Caption = $Value;
        return true;
    }
    function getWelcomeMessage () {
        // function: getCaption()
        // parameter: none
        $this->debug_log(__FUNCTION__);        
        return $this->WelcomeMessage;
    }
    function setWelcomeMessage( $Value ) {
        // function: setCaption()
        // parameter: Value = new value for this property
        $this->debug_log(__FUNCTION__, $Value);
        $this->WelcomeMessage = $Value;
        return true;
    }
    //-- constructor -----------------------------------------------------
    function __construct() {
        // function: __construct
        // parameter: none

        // -- run parent constructor ----------------------------------------
        parent::__construct();
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
    //-- destructor ------------------------------------------------------
    function __destruct() {
        // function: __destruct
        // parameter: none
        $this->debug_log(__FUNCTION__);
    }
}

?>