<?PHP
/* 
Filename: class_database.php
Content.: class definition for base database class
Create..: 2020-09-24
Change..: 2020-09-24 create by D.Goetze
*/

abstract class DataBase extends BaseClass{

    public $Server   = "";
    public $User     = "";
    public $Password = "";

    public $Name     = "";
    public $Prefix   = "";
    
    public abstract function Execute( $sql );
    public abstract function GetTables();
    public abstract function GetColumns( $table );
    public abstract function ReadField( $sql );
    public abstract function ReadRow( $sql );
    public abstract function ReadRows( $sql );
    public abstract function Connect();
    public abstract function Disconnect();

    public function __construct( $config ) {
        // -- run parent constructor ----------------------------------------
        parent::__construct();
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, $config);
        include( $config );
        // -- set connction parameters --------------------------------------
        $this->Server   = $dbhost;
        $this->debug_log('', '$this->Server..: '.$this->Server);
        $this->User     = $dbuser;
        $this->debug_log('', '$this->User....: '.$this->User);
        $this->Password = $dbpassword;
        $this->debug_log('', '$this->Password: '.$this->Password);

        $this->Name     = $db;
        $this->debug_log('', '$this->Name....: '.$this->Name);
        $this->Prefix   = $dbpraefix;
        $this->debug_log('', '$this->Prefix..: '.$this->Prefix);

        // -- try connection ------------------------------------------------
        $this->Connect();

    }
}
?>