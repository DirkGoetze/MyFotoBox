<?php 
/* 
Filename: class_baseclass.php
Content.: class definition for the base class of all fotobox class
Create..: 2020-09-24
-----------------------------------------------------------------------------
Changes
-----------------------------------------------------------------------------
2020-09-24 create by D.Goetze
*/
    
class BaseClass {
    // -- declare class propertys -------------------------------------------
    public $DebugMode;
    // -- declate protected class constantes --------------------------------
    // -- declate private class constantes ----------------------------------
    // -- create a debug output ---------------------------------------------
    public function debug_log() {
        // function: debug_log()
        // parameters: $calledFkt = name of called function
        if ($this->DebugMode !== false) {
            // -- at first a new line and HTML comment begin tag ------------
            print "<!-- ";
            // -- prepare all parameters for output -------------------------
            $argument = "";
            
            foreach ( func_get_args() as $key => $value ) {
                if ($key == 0) {
                    $calledFkt = $value;
                } else {
                    if (strlen($argument) <= 1) {
                        $argument .= "'".$value."'";
                    } else {
                        $argument .= ", '".$value."'";
                    }
                }
            }

            if ( (strlen($calledFkt) != 0 ) OR (strlen($argument) != 0 ) ) {
                // -- output debug message ----------------------------------
                print get_class($this)."->".$calledFkt."(".$argument.");";
            } else {
                $class_propertys = get_class_vars( get_class($this) );
                //print_r ($class_propertys);
                print "\naktuelle Eigenschaften \n";
                foreach ( $class_propertys as $name => $value ) {
                    print "   [".get_class($this)."->".$name."] = ".$value."\n";
                }
                $class_methods = get_class_methods( get_class($this) );
                sort($class_methods);
                //print_r ($class_methods);
                print "aktuelle Methoden \n";
                foreach ( $class_methods as $name ) {
                    print "   ".get_class($this)."->".$name."\n";
                }
            }
            // -- HTML comment close tag ------------------------------------
            print " //-->\n";
        }
    }
    // -- get/set propertys -------------------------------------------------
    public function getDebugMode () {
        // function: getDebugMode()
        // parameter: none
        $this->debug_log(__FUNCTION__);
        return $this->DebugMode;
    }
    public function setDebugMode( $Value ) {
        // function: setCaption()
        // parameter: Value = new value for this property

        // -- create a debug log --------------------------------------------
        $this->debug_log(__FUNCTION__, $Value);
        // -- set new value 
        $this->DebugMode = $Value;
        // -- return success ------------------------------------------------
        return true;
    }
    //-- constructor --------------------------------------------------------
    function __construct() {
        // function: __construct
        // parameter: none
        // 
        // -- apply the global debug settings -------------------------------
        $this->DebugMode = DEBUG_MODE;

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
    //-- destructor ---------------------------------------------------------
    function __destruct() {
        // function: __destruct
        // parameter: none

        // Debug Meldung erzeugen
        $this->debug_log(__FUNCTION__);
    }
}

?>