<?php
/* 
Filename: class_filetools.php
Content.: class definition for the file helper class
Create..: 2020-09-24
Change..: 2020-09-24 create by D.Goetze
*/

class FileTools extends BaseClass {
    // -- declare class propertys -------------------------------------------
    // -- declate protected class constantes --------------------------------
    // -- declate private class constantes ----------------------------------
    // -- get/set propertys -------------------------------------------------
    // -- get/set propertys -------------------------------------------------
    // -- helper functions --------------------------------------------------
    public function filterfilename( $filename ) {
        // function: filterfilename
        // parameter: $filename
        
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, $filename);

        // -- prepare filename and check securety lines ---------------------
        $filename = strtolower($filename);
        //$filename = preg_replace("/[^a-z0-9-/]/i","", $filename);
        if($filename[0] == "/"){
            $filename = substr($filename, 1); }
        $filename .= ".php";
        if(!file_exists($filename)){
            $filename = "content/pages/errors/404.php";
        }

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, 'return = '.$filename);

        // -- return result -------------------------------------------------
        return $filename;
    }
    //-- constructor -----------------------------------------------------
    function __construct() {
        // function: __construct
        // parameter: none

        // -- run parent constructor ----------------------------------------
        parent::__construct();
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
    //-- destructor ------------------------------------------------------
    function __destruct() {
        // function: __destruct
        // parameter: none

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
}

?>