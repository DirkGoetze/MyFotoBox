<?PHP
/* 
Filename: class_mysql.php
Content.: class definition for mysql handling class
Create..: 2020-09-24
Change..: 2020-09-24 create by D.Goetze
*/
    
class MySQL extends DataBase {
    private $Connection;
      
    public function Execute($sql) {
        //return $this->Connection->query( str_replace("{'dbprefix'}", $this->Prefix, $sql));
    }
    
    public function GetTables() {
        /*
        $res = $this->Connection->query( "SHOW TABLES" );
        while( $row = $res->fetch_row() ) {
            $tables[] = $row[0];
        }
        sort( $tables );
        return $tables;
        */
    }
        
    public function GetColumns($table) {
        /*$mysqlres = $this->Execute("SHOW COLUMNS FROM ".$table);
        while( $row = $mysqlres->fetch_object() ) {
            $res[] = $row;
        }
        return $res;
        */
    }

    public function ReadField($sql) {
        /*
        $res = $this->Execute($sql);
        $row = $res->fetch_row($res);
        return $row[0];
        */
    }

    public function ReadRow($sql) {
        /*
        $res = $this->Execute($sql);
        return $res->fetch_object();
        */
    }

    public function ReadRows($sql) {
        /*
        $mysqlRes = $this->Execute($sql);
        while( $row = $mysqlRes->fetch_object() ) {
            $res[] = $row;
        }
        return $res;
        */
    }
      
    public function EscapeString($text) {
        /*
        return $this->Connection->real_escape_string($text);
        */
    }

    public function Connect() {
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);

        //$this->Connection = mysql_connect($this->Server, $this->User, $this->Password);
        $this->debug_log(__FUNCTION__, '$this->Connection ='.$this->Connection);
    }

    public function Disconnect() {
        $this->Connection->close();
    }  
}

?>