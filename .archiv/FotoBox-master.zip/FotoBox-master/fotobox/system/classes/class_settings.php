<?php
/* 
Filename: class_settings.php
Content.: class definition for the settings class
Create..: 2020-09-24
Change..: 2020-09-24 create by D.Goetze
*/

define ('DEFAULT_CONFIG_DIR', 'system/config');

class Settings extends BaseClass {
    // -- declare class propertys -------------------------------------------
    private $ConfigFolder;
    // -- declate protected class constantes --------------------------------
    // -- declate private class constantes ----------------------------------
    // -- get/set propertys -------------------------------------------------
    // -- get/set propertys -------------------------------------------------
    public function getConfigFolder () {
        // function: getDebugMode()
        // parameter: none

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);

        // -- prepare result ------------------------------------------------
        $res  = DEFAULT_CONFIG_DIR ;
        if ( is_dir($res) != true ) { mkdir($res, 0777); }
        $res .= '/';

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, $ClassName, 'return = '.$res);
        
        // -- return result -------------------------------------------------
        return $res;
    }
    public function getConfigFileName ( $ClassName) {
        // function: getDebugMode()
        // parameter: none
        
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, $ClassName);
        
        // -- prepare result ------------------------------------------------
        $res = $this->getConfigFolder() . strtolower( $ClassName ) .'.cnf';
        if ( file_exists($res) != true) { touch($res); }
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__, $ClassName, 'Result: '.$res);
        
        // -- return result -------------------------------------------------
        return $res;
    }
    //-- constructor --------------------------------------------------------
    function __construct() {
        // function: __construct
        // parameter: none

        // -- run parent constructor ----------------------------------------
        parent::__construct();
        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
    //-- destructor ------------------------------------------------------
    function __destruct() {
        // function: __destruct
        // parameter: none

        // -- create a debug log message ------------------------------------
        $this->debug_log(__FUNCTION__);
    }
}

?>