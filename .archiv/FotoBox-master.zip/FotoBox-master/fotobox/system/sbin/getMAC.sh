﻿#!/bin/bash
#
# Usage:
# ./getMac.sh 192.168.178.1 eth0
#
# Parameter 1 = IP-Adresse
# Parameter 2 = Interface
#

ipaddress="$1"
interface="$2"

result=$(sudo arping -i $interface $ipaddress -c 2 | grep '('$ipaddress')' | grep index=1 | awk '{ print $4 }')
echo $result;

 
