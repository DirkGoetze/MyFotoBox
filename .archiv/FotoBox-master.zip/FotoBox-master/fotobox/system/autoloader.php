<?php

/**
 * Läd Klassen automatisch anhand bestimmter Regeln
 */
class AutoLoader {
    // -- verwendete globale Variablen --
    
    // -- Klassen Eigenschaften --
    private $loadRules = array();
    private $loadedClasses = array();
 
    /**
     * Gibt einen Array zurück der die Pfade aller geladenen Dateien enthält (Für Debugzwecke)
     * @return array
     */
    public function getLoadedClasses() {
        // debug
        if (DEBUG_MODE == true) {
            print "<!-- ".get_class($this)."->getLoadedClasses() \n";
            print_r ($this->loadedClasses);
            print "//-->\n";
        }
        
        return $this->loadedClasses;
    }
 
    /**
     * Definiert eine Regel, anhand dieser Dateien geladen werden
     * @param      $beforeClassName     Präfix für den Dateinamen (z.B. "class_")
     * @param      $afterClassName      Ende des Dateinamens inklusive Erweiterung (z.B. ".php")
     * @param      $folder              Voller Pfad des Ordners, in dem die Datei gesucht werden soll
     * @param bool $recursive           Gibt an ob nur in $folder gesucht werden soll oder auch rekursiv in Unterordnern von $folder
     */
    public function addLoadRule( $beforeClassName, $afterClassName, $folder, $recursive = true) {
        // debug
        if (DEBUG_MODE == true) {
            print "<!-- AutoLoader->addLoadRule(".$beforeClassName.", ".$afterClassName.", ".$folder.", ".$recursive.") //-->\n";
        }

        $this->loadRules[] = array(
            'beforeClassName' => $beforeClassName,
            'afterClassName' => $afterClassName,
            'folder' => $folder,
            'recursive' => $recursive
        );
    }
 
    /**
     * Startet den AutoLoader, sodass ab diesem Zeitpunkt alle verwendeten Klassen die nicht geladen wurden über die Regeln des AutoLoaders geladen werden
     */
    public function startWork() {
        // debug
        if (DEBUG_MODE == true) {
            print "<!-- ".get_class($this).":startWork() //-->\n";
        }

        spl_autoload_register( array( $this, 'loadClass') );
    }
 
    /**
     * Läd eine von spl_autoload_register angeforderte Klasse
     * @param $className    Name der zu ladenden Klasse (Groß/Kleinschreibung wird ignoriert)
     */
    private function loadClass( $className ) {
        // debug
        if (DEBUG_MODE == true) {
            print "<!-- ".get_class($this)."->loadClass(".$className.") //-->\n";
        }

        foreach( $this->loadRules as $loadRule ) {
            // Dateiname ermitteln und Datei laden
            $fileName = $loadRule['beforeClassName'] . strtolower( $className ) . $loadRule['afterClassName'];
            $fullFilePath = self::searchFile( $loadRule['folder'], $fileName, $loadRule['recursive'] );
            // Datei einbinden, sofern sie gefunden wurde
            if( false !== $fullFilePath) {
                $this->loadedClasses[] = $fullFilePath;
                require_once $fullFilePath;
            }
        }
    }
 
    /**
     * Durchsucht einen Ordner nach einer Datei
     * @param      $dir         Vollständiger Pfad des Ordners, der durchsucht werden soll
     * @param      $fileName    Name der Datei, die gesucht wird
     * @param bool $recursive   Gibt an ob nur in $dir gesucht wird oder auch rekursiv in dessen Unterordnern
     * @return bool|string      Vollständiger Pfad der gefundenen Datei oder FALSE, wenn die Suche kein Ergebnis lieferte
     */
    public static function searchFile( $dir, $fileName, $recursive = true) {
        // debug
        if (DEBUG_MODE == true) {
            print "<!-- AutoLoader->searchFile('".$dir."', '".$fileName."', ".$recursive.") //-->\n";
        }

        // Symlinks für übergeordnete Verzeichnisse entfernen
        $files = array_diff( scandir( $dir ), array( '.', '..' ) );
        foreach( $files as $file ) {
            $fullPath = $dir . '/' . $file;
            if( is_dir($fullPath) && $recursive ) {
                // Es handelt sich um einen Unterordner: Rekursiv scannen, sofern gewünscht
                $subdirScanResult = self::searchFile( $fullPath, $fileName );
                if( false !== $subdirScanResult ) {
                    return $subdirScanResult;
                }
            }else {
                // Es handelt sich um eine Datei: Entspricht diese der gesuchten?
                if( strtolower( $file ) == strtolower( $fileName) ){
                    return $fullPath;
                }
            }
        }
        // Keine Datei gefunden
        return false;
    }
}