<?php

// -- database server access
$dbhost = "192.168.20.100";
$dbuser = "fbx_user";
$dbpassword = "123456";

// -- database config
$db = "MyFotoBox";
$dbpraefix = "fbx_";
        
?>