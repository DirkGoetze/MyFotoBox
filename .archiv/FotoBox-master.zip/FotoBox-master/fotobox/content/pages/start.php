<!-- page template : start //-->
<header>
    <div>Logo</div>
    <div><?php print $MyFotoBox->getCaption(); ?></div>
</header>

<nav>
    <div>
        <ul>
            <li><a href="index.php?include=start">Start</a></li>
            <li><a href="index.php?include=upload">Upload</a></li>
            <li><a href="index.php?include=gallery">Gallery</a></li>
        </ul>
    </div>
</nav>

    <!-- template for login dialog //-->
    <button name="login" onclick="toggleDialog()">Dialog open</button>
    <dialog id="login-dialog" role="dialog" aria-labelledby="dialog-heading">
        <button id="close">x</button>
        <h2 id="login-dialog-heading">Benutzername</h2>
        <p>
            <label data-text for="prompt-user">Mach es uns einfacher. Um später deine Bilder schneller zuzuordnen, sage uns deinen Namen!</label>
            <!-- TODO: autofocus für Nutzername setzen //-->
            <input id="prompt-user" name="username" type="text" placeholder="Dein Name">
            <label data-mac for="promt-mac">Zusätzlich werden wir die Kennung deines Gerätes speichern.</label>
            <input id="promt-mac" name="macaddress" type="text" value="<?php print $_SESSION['MAC']; ?>">
        </p>
        <p class="button-row">
            <button name="cancel">Abbrechen</button>
            <button name="ok">OK</button>
        </p>
    </dialog>

<main>
    <div>
        <p>Was ist die Fotobox?</p>
        <p>Wie verbinde ich mich mit der Fotobox?</p>
    </div>
</main>

<aside>
    <div>
        <p></p>
    </div>
</aside>