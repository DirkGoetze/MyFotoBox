<!-- page template : gallery //-->
<header>
    <div>Logo</div>
    <div><?php print $MyFotoBox->getCaption(); ?></div>
</header>

<nav>
    <div>
        <ul>
            <li><a href="index.php?include=start">Start</a></li>
            <li><a href="index.php?include=upload">Upload</a></li>
            <li><a href="index.php?include=gallery">Gallery</a></li>
        </ul>
    </div>
</nav>

<main>
    <div>
        <p>Gallery</p>
    </div>
</main>

<aside>
    <div>
        <p></p>
    </div>
</aside>