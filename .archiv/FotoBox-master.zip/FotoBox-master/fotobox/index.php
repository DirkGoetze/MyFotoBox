<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de">
    <head>
        <title>Kommt in einen sp&auml;teren Beitrag</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="stylesheet" href="system/css/default.css">
        <script language="javascript" type="text/javascript" src="system/js/dialog.js"></script>
    </head>
    <body>
    <div id="brackdrop"></div>
    <?php

    // -- session init ------------------------------------------------------
    error_reporting(E_ALL);

    if ( ! session_id() ) {
        session_start();
        if ( ! isset($_SESSION['USR'])) $_SESSION['USR'] = '';
        if ( ! isset($_SESSION['IP'])) $_SESSION['IP'] = $_SERVER['REMOTE_ADDR'];
        if ( ! isset($_SESSION['MAC'])) {
            $interface = "eth0";
            $macaddr = shell_exec( 'sudo system/sbin/getMAC '.$_SESSION['IP'].' '.$interface );
            if (preg_match('/^([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$/', $macaddr)) {
                $_SESSION['MAC'] = trim( $macaddr );
            } else {
                $_SESSION['MAC'] = '00:00:00:00:00:00';
                $_SESSION['USR'] = 'unknow';
            }
        }
    }
    print "\n<!-- SESSION: \n";
    print_r ( $_SESSION );
    print_r ( getallheaders() );
    print "\n//-->\n";
    
    // -- define global settings --------------------------------------------
    define( 'DEBUG_MODE', false );               // switch global debug mode
    define( 'BASE_DIR', __DIR__ );               // read base folder 
    define( 'INCLUDE_DIR', 'system');            // set class folder
    define( 'CONFIG_DIR', 'system/config');      // set config folder
    
    // -- autoload for all required classes ---------------------------------
    require_once INCLUDE_DIR . '/autoloader.php';// include autoloader class
    $autoLoader = new Autoloader();              // autoloader create
    $autoLoader->addLoadRule( 'class_', '.php', INCLUDE_DIR );
    $autoLoader->startWork();
        
    // -- prepare helper classes --------------------------------------------
    $Settings = new Settings();
    $FileUtilitys = new FileTools();
    //$FileUtilitys->setDebugMode( false );
    
    // -- prepare database --------------------------------------------------
    $cnf_file = CONFIG_DIR . '/db.cnf.php';
    //$MyConnection = new MySql($cnf_file);
    //$MyConnection->setDebugMode( true );

    // -- prepare main class ------------------------------------------------
    $MyFotoBox = new FotoBox();
    //$MyFotoBox->setDebugMode( true );
    $MyFotoBox->setCaption('Foto-Box');
    $MyFotoBox->setWelcomeMessage('Willkommen an der Foto-Box.');

    include($FileUtilitys->filterfilename("content/pages/".$_GET['include']));
    
    ?>

    </body>
</html>
