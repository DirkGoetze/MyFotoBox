Fotobox (Version 0.0.0.1)

Ziel: Fotobox

Installation
-----------------------------------------------------------------------------
1.  Raspberry-PI einrichten





- WEB Modul
- Unterordner auf WEB-Server
- .htaccess anlegen
- alle Dateien dorthin entpacken
- Einstellungen über Config Seite